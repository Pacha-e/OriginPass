# OriginPass

**Prove where a product came from, without having to trust the seller.**

OriginPass is a web application that issues a verifiable digital passport for every physical product and records each change of custody along its journey. A buyer scans a QR code and sees whether the product is genuine, who made it, and the path it took to reach the shelf. No account is needed to check.

The project is being built for ST0251 Proyecto Integrador 1, 2026-2, at Universidad EAFIT.

## Wiki index

| Page | Contents |
|---|---|
| [Team](Team) | Who is working on the project and in which role |
| [Project Overview](Project-Overview) | What the product is, who it serves, and how it works |
| [Product Vision Board](Product-Vision-Board) | Vision, target group, needs, product and business goals |
| [Elevator Pitch](Elevator-Pitch) | The pitch, in one minute |
| [Problem Validation](Problem-Validation) | Evidence collected to confirm the problem is real |
| [Primary Research Plan](Primary-Research-Plan) | The survey, the interview channels and the message to send |
| [Requirements Specification](Requirements-Specification) | Functional, usability and logical database requirements |
| [Requirements Prioritisation](Requirements-Prioritisation) | MoSCoW prioritisation and sprint assignment |
| [Domain Model](Domain-Model) | Entities, relationships and state machines |
| [Deliverable 1](Deliverable-1) | Project definition and software requirements specification |
| [Deliverable 1 Video](Deliverable-1-Video) | Script, timing and the walkthrough to record |
| [Deliverable 2](Deliverable-2) | Solution design and functionality preview |
| [Deliverable 3](Deliverable-3) | The MVP: chain of custody, analytics, corporate image |
| [Sprint 1 Review](Sprint-1-Review) | What was committed, what was delivered and how it was verified |
| [Sprint 2 Plan](Sprint-2-Plan) | Sprint goal, scope, build order and risks |
| [Sprint 2 Review](Sprint-2-Review) | What was committed, what was delivered and how it was verified |
| [Development Log](Development-Log) | What was built each week, what came next, what stood in the way |
| [Retrospectives](Retrospectives) | What to continue, start and stop doing |
| [Activities and Homeworks](Activities-and-Homeworks) | Class assignments |

## Current status

Sprint 2 is closed. All twenty-two committed requirements were delivered and are covered by one hundred and seventy-nine automated tests running against PostgreSQL 17; the detail is on the [Sprint 2 Review](Sprint-2-Review) page.

The application now does the thing it exists to do: an approved company registers a product and gets a QR code for it, and any buyer scans that code and reads a verdict without an account. The interface is served in Spanish. Custody transfers and the analytics follow in later sprints; their tables already exist.

The largest open item is the primary research on the [Problem Validation](Problem-Validation) page, which has now been carried for three sprints and has not been carried out.

The sprint calendar set by the course is:

| Sprint | Dates | Review |
|---|---|---|
| 1 | 15 July – 11 August 2026 | 11 August |
| 2 | 12 August – 8 September 2026 | 8 September |
| 3 | 9 September – 13 October 2026 | 13 October |
| 4 | 14 October – 10 November 2026 | Final presentations, 3 and 10 November |
