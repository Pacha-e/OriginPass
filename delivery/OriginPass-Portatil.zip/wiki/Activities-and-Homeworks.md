# Activities and Homeworks

Class activities, in the order they were set.

| # | Activity | Session | Status | Where it lives |
|---|---|---|---|---|
| 1 | Product vision board for Flik's project, "The Fake Bird" | 14 July | *to be completed* | Below |
| 2 | Analyse the product vision of "The Fake Bird" | 14 July | *to be completed* | Below |
| 3 | Analyse the product vision board for "The Fake Bird" | 14 July | *to be completed* | Below |
| 4 | Write the vision of your product | 14 July | Done | [Product Vision Board](Product-Vision-Board) |
| 5 | Elaborate the product vision board for your project | 14 July | Done | [Product Vision Board](Product-Vision-Board) |
| 6 | Requirements prioritisation, selecting the twenty most relevant | 21 July | Done | [Requirements Prioritisation](Requirements-Prioritisation) |
| 7 | Requirements written with the specification template | 21 July | Done | [Requirements Specification](Requirements-Specification) |
| 8 | Backlog in GitHub Projects | 28 July | Done | [Backlog](https://github.com/users/Pacha-e/projects/1) |
| 9 | Elevator pitch | 4 August | Done | [Elevator Pitch](Elevator-Pitch) |

---

## Activity 4 — Vision of the product

> Is a service for artisans, small manufacturers and the people who buy from them, who have to prove that a physical product is genuine and trace where it came from. It is called OriginPass and is a web application that issues a verifiable digital passport for every product and records each change of custody along its journey. Unlike printed certificates and brand-owned label checkers, our service lets any buyer verify a product without creating an account, and shows the full custody chain from maker to current owner.

## Activity 5 — Product vision board

See [Product Vision Board](Product-Vision-Board).

## Activity 6 — Requirements prioritisation

Technique applied: MoSCoW. The twenty most relevant requirements, the reasoning behind the choice of technique, and the assignment of every requirement to a sprint are on the [Requirements Prioritisation](Requirements-Prioritisation) page.

## Activity 7 — Requirements using the template

Seventy-seven requirements written with the six-slot template, on the [Requirements Specification](Requirements-Specification) page.

## Activity 8 — Backlog in GitHub Projects

Seventy-seven issues, one per requirement, numbered so that issue #N is the Nth requirement. Each carries labels for its sprint, its MoSCoW priority and its kind. The eighteen Sprint 1 issues were written with acceptance criteria and are now closed, each with the commit and the test that verifies it.

## Activity 9 — Elevator pitch

On its own page: [Elevator Pitch](Elevator-Pitch).
