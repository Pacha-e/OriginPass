# Deliverable 3: MVP

Sprint 3 makes OriginPass do what it exists to do end to end: a workshop issues a
passport, the piece changes hands along a signed chain of custody, a buyer scans it and
reads a verdict with the journey of the piece, and the workshop is told when one of its
codes is scanned in two places at once. Several Sprint 4 requirements were built early
and are listed as such.

Repository: https://github.com/Pacha-e/OriginPass · branch `sprint-3-mvp`

> **Scope and verification.** The MVP uses Django/PostgreSQL, not Monad. A future product seeks direct anchoring of integrity evidence on Monad. A copied QR still resolves the same record and cannot by itself prove physical authenticity. The company application accepts unregistered artisan workshops with private craft-evidence notes for human review. This page identifies pending rubric gates rather than presenting them as completed.

---

## 1. Architecture and data

Every diagram is a draw.io file in [`docs/diagrams/`](https://github.com/Pacha-e/OriginPass/tree/sprint-3-mvp/docs/diagrams).
**What changed in Sprint 3 is drawn in orange in each one**, with its own legend entry, so
the change can be read off the diagram as well as from the lists below.

### 1.1. Deployment diagram

[`deployment-model.drawio`](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/docs/diagrams/deployment-model.drawio)

| Node | Software | Talks to |
|---|---|---|
| Buyer's phone | Any mobile browser, a camera that reads QR codes | Application server, HTTPS |
| Company or administrator workstation | Any desktop browser | Application server, HTTPS |
| Application server | Ubuntu 24.04, Python 3.12, Django 5.2 | Database (TCP 5432), mail service (SMTP 587) |
| Database server | PostgreSQL 17 | — |
| Mail service *(new)* | Any SMTP provider; Django's console backend in development | — |
| GitHub | Repository, wiki, backlog, Actions runner with `postgres:17-alpine` | — |

**Changes in Sprint 3**

- **Mail service.** Notifications (FR53 decisions, FR54 transfer offers, FR55 revocations) and
  the password reset link (FR06) leave the application server over SMTP. In development the
  same calls print the message on the console, so nothing about the code changes between the two.
- **CDN headers.** The scan region (FR33) is read from the geolocation headers a CDN adds
  (`CF-Region`, `CF-IPCountry`). They are trusted only when the deployment says a CDN is in
  front (`TRUST_GEO_HEADERS`), because elsewhere a client could forge them and raise false
  copy alerts against a genuine producer.
- **Database.** Two new tables and one new column, below.

### 1.2. Component diagram

[`components-model.drawio`](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/docs/diagrams/components-model.drawio)

One component per Django app; business rules in the models, validation in the forms,
orchestration in the views. Each function drawn is a view reachable from the interface.

| Component | Responsibility | Added in Sprint 3 |
|---|---|---|
| `accounts` | Accounts, sessions, roles; outgoing email | Login lockout after five failures in fifteen minutes (FR57); password reset with Django's signed, expiring tokens (FR06); the notification module (FR53–FR55) |
| `companies` | Applications and their review | Suspension and reactivation with a stored reason (FR15, FR16); public profile of an approved company (FR18) |
| `products` | Passports, QR, chain of custody, company analytics | Custody page, offer, accept or decline, claim with two codes (FR35–FR40); analytics by day, region and product with the trend against the previous period and CSV export (FR46–FR49, FR51, FR52); revocation by the company and by the administrator (FR41, FR42); platform overview (FR50) |
| `verification` | The public verdict page | The journey of the piece (FR32), region of each scan (FR33), duplicate-scan alert (FR49), cap of 60 recorded scans per address per hour (FR58) |
| `audit` | Signed, chained trail of every status change | The administrator's audit log filtered by actor, action and date, with the integrity of the whole chain checked on every view (FR44, FR45) |
| `pages` | The landing page | Redesigned with the corporate image |

### 1.3. Data model

[`data-model.drawio`](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/docs/diagrams/data-model.drawio)

Eight tables in PostgreSQL 17. **Changes in Sprint 3:**

| Change | Table | Why |
|---|---|---|
| New table | `accounts_loginattempt` (email, ip_address, failed_count, first_failed_at, locked_until) — unique per (email, ip_address) | FR57: a failure streak per address and origin |
| New table | `products_alert` (product_id → product, scan_id → scan, kind, created_at) — unique per (product, scan) | FR49: one alert per suspicious scan |
| New column | `products_custodytransfer.transfer_code` (uuid, unique) | FR40: the code the seller hands over at the sale |
| New constraint | `custody_transfer_one_open_offer`: partial unique index on `product_id` where `state = 'INITIATED'` | A piece is offered to one account at a time, so it cannot be sold twice even under concurrent requests |

The rules that can be stated in SQL are held by the database as well as by the
application: five check constraints and four unique constraints, all listed in the diagram.

**Editable schema updated 15 October:** `companies.0002` adds `evidence_notes` (private)
 and `publish_consent` (boolean); both fields are now drawn as orange rows in the
 editable RDS `.drawio`. The pre-existing PNG export has **not** been regenerated
 and must not be presented as the final schema; open/export the updated `.drawio`
 on diagrams.net before presenting it. No Monad contract or chain data exists
 in this deployment.

---

## 2. Corporate image

The full brand sheet, with the reasoning behind each choice, is
[`docs/brand/`](https://github.com/Pacha-e/OriginPass/tree/sprint-3-mvp/docs/brand).

**Logo.** A **P** whose bowl is concentric rings: seen from above, a sombrero vueltiao is
rings of braided caña flecha; read again, the rings are a fingerprint, the identity that
cannot be copied. [`originpass-logo.svg`](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/static/brand/originpass-logo.svg)

**Slogan.** *El origen no se imita.*

**Palette.**

| Name | Hex | Role |
|---|---|---|
| Añil | `#1E2B58` | Brand, headings, primary actions: the natural dye of the region's textiles and the ink of security printing |
| Caña flecha | `#D9C28A` | The woven thread, the rings; never text |
| Papel | `#F3F4EE` | Page background |
| Sello | `#17694A` | Verdict *Auténtico* |
| Carmín | `#A3253C` | Verdict *Anulado* (revoked), refusals |
| Ámbar | `#86560A` | Verdict *No encontrado*, pending states |

Every text colour clears 4.5 to 1 against its background (UR09).

**Typography.** Headings in Bahnschrift, the DIN of official forms and road signs; text in
the system face; codes in OCR-B where installed, the face of a passport's machine-readable zone.

**Plain language and built-in help.** One of the target users is the rural artisan or farmer, often on a phone. Every action carries a sentence saying what it does (a tooltip with a mouse, printed under the button on a phone), every term has a "?" that opens its meaning in place, every form field explains itself before the input with an example inside it, and the interface uses one plain word per idea: *producto*, *entregar*, *código de entrega*, *recibir*, *anular*. A test fails if the old vocabulary (custodia, traspaso, revocar) comes back. Real photographs of the crafts, from Wikimedia Commons, are credited on the site's credits page.

**The identity in the product.** The public verdict is laid out as the data page of a
passport: a guilloche seal stamped once in the colour of the answer, the product's fields,
and the machine-readable strip at the foot. A strip of the vueltiao's woven zigzag runs
under the header of every page.

| Screen | |
|---|---|
| Landing | ![](https://raw.githubusercontent.com/Pacha-e/OriginPass/sprint-3-mvp/docs/brand/screenshots/01-inicio.png) |
| Verdict *Auténtico* with the journey of the piece | ![](https://raw.githubusercontent.com/Pacha-e/OriginPass/sprint-3-mvp/docs/brand/screenshots/05-veredicto-autentico.png) |
| Verdict *Anulado* (revoked) with its reason | ![](https://raw.githubusercontent.com/Pacha-e/OriginPass/sprint-3-mvp/docs/brand/screenshots/06-veredicto-revocado.png) |
| Verdict on a 360 px phone | ![](https://raw.githubusercontent.com/Pacha-e/OriginPass/sprint-3-mvp/docs/brand/screenshots/30-movil-veredicto.png) |
| Company analytics and copy alert | ![](https://raw.githubusercontent.com/Pacha-e/OriginPass/sprint-3-mvp/docs/brand/screenshots/12-empresa-analitica.png) |
| Passport with an open offer and its transfer code | ![](https://raw.githubusercontent.com/Pacha-e/OriginPass/sprint-3-mvp/docs/brand/screenshots/11-empresa-detalle-oferta.png) |
| Administrator overview | ![](https://raw.githubusercontent.com/Pacha-e/OriginPass/sprint-3-mvp/docs/brand/screenshots/20-admin-panel.png) |
| Audit log | ![](https://raw.githubusercontent.com/Pacha-e/OriginPass/sprint-3-mvp/docs/brand/screenshots/24-admin-auditoria.png) |

---

## 3. Repository

**Repository:** https://github.com/Pacha-e/OriginPass — the project is carried out
individually, so every commit is by Emmanuel Hernández Melo.

- [`requirements.txt`](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/requirements.txt) lists every library needed to run it; `requirements-dev.txt` adds the pinned linter.
- The [README](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/README.md) has the commands to run it, the demo accounts and the two settings a demo depends on.
- [`delivery/OriginPass-Portatil.zip`](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/delivery/OriginPass-Portatil.zip) is the Windows presentation kit. The [setup guide](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/delivery/LEEME-PORTATIL.md), separate PowerShell scripts and SHA-256 checksum are in the same directory. The archive includes current source, demo media and local wiki drafts, but no personal environment file, live database or virtualenv. It must be rehearsed on the actual laptop before class.
- Emmanuel checked Interactiva and reports **no direct upload activity** for this delivery. The evidence is the GitHub repo/wiki and the class presentation; no LMS receipt is claimed.
- `python manage.py seed_demo` builds a dataset that shows every Sprint 3 feature: a piece
  that travels workshop → distributor → private buyer, an open offer with its transfer
  code, a month of scans from several regions and a duplicate-scan alert.

**Verified locally on 15 October:** 314/314 Django/PostgreSQL tests passed on the desktop; `verify_integrity` returned successfully. The portable archive was checked byte-for-byte against its source, and extracted Django `check` passed. These are **not** tests of the destination laptop or proof of a successful remote CI run. The published commit and CI result should be checked by readers in the linked Sprint 3 branch.

---

## 4. Video

**Required, not completed:** provide an accessible YouTube or Vimeo link to a verified
4:00–5:00 video. Emmanuel, the sole team member, must appear on camera. The existing
7:23 academic cut is outside this range; the 56-second Andino promotional film is
supplementary, not a replacement. No final video or public link has been verified.

| Part | Length | Contents |
|---|---|---|
| Pitch, by one member | 1:00 | Team, project name, problem, solution, where the project is and where it is going |
| Requirements addressed | 1:00 | Chain of custody, analytics and alerts, revocation, account protection |
| Evidence of compliance | 2:00 | The walkthrough in [`docs/GUIA-DEMO.md`](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/docs/GUIA-DEMO.md) |
| Product Owner perception | 1:00 | Emmanuel is the Product Owner and will record his own real assessment; no producer or buyer testimonials exist and none will be invented. |

---

## 5. Project management

### 5.1. Backlog

The [Backlog](https://github.com/users/Pacha-e/projects/1) and the [Requirements Specification](Requirements-Specification) now have acceptance criteria on all 20 Sprint 3 issues; the live FR38 item was moved to Done after its non-holder refusal tests were verified. Some criteria are explicitly **pending manual evidence**: the five-second analytics target, end-to-end keyboard traversal, rendered-page contrast audit and elapsed 24-month retention cannot be inferred from the unit suite. Do not confuse an issue's Done field with all criteria having been observed.

| Sprint 3 requirement | Status |
|---|---|
| FR18, FR32, FR33, FR35–FR37, FR39–FR40, FR46–FR50 | Marked Done on the live board; see individual issues for test evidence and manual checks |
| FR38 | Done on the live board; refusal and visible reason covered by `test_a_non_holder_is_refused_with_the_reason` |
| DBR05, DBR06, DBR07 | Done (custody and scan records, accepted transfers immutable) |
| UR07, UR09 | Done on board for implemented focus styles and documented palette ratios; full keyboard walkthrough and rendered-page audit still pending |
| DBR09 (24-month retention) | Done on the board as a no-automatic-deletion policy; 24 elapsed months and backup recovery have not been proven and remain manual evidence gates |

| Sprint 4 requirement built early | Status |
|---|---|
| FR06, FR15, FR16, FR41, FR42, FR44, FR51, FR52, FR53, FR54, FR55 | Done, each with tests |
| FR27, FR34, FR56, UR05 | Open |

### 5.2. Individual daily log (professor-approved substitute for meetings)

[Daily Log](Daily-Log) is the individual day-by-day bitácora requested by the professor **instead of team-meeting minutes**, since Emmanuel is the sole member. It cites dated commits and labels days with no surviving record honestly. [Development Log](Development-Log) contains the more detailed weekly narrative and the documented October 1 feedback. Record only actual Product Owner decisions; do not invent attendees.

### 5.3. Product Owner feedback (Emmanuel, 15 October)

Emmanuel requested: an obvious way to upload photographs for registered products; greater variety of products and companies in the demonstration; and explicit coverage of both formal firms and informal artisan workshops. The MVP currently accepts an optional product image at creation **and on later edit**; an automated test uploads a JPEG after registration and checks that the public verification page exposes it. This does not provide a multi-photo gallery or a bulk upload: those remain product improvements. The local demonstration seed was expanded with a formal textile company, an informal basketry workshop and three additional product passports (seven examples total). These are **fictitious demo records**, not approved real businesses. Formal firms follow registry-document review; informal workshops provide craft/provenance evidence and undergo human review. Neither route guarantees the authenticity of the physical item merely from its QR. This is Emmanuel's feedback as PO, not a fabricated third-party testimonial.

### 5.4. Retrospective

[Retrospectives](Retrospectives) currently contains Sprint 1 and 2 only. A Sprint 3 retrospective must be recorded after its actual review, answering Continue / Start / Stop; it is pending.

---

## 6. Sprint Review

**Review not independently confirmed.** Prepare the single-member pitch and live demonstration in
[`docs/GUIA-DEMO.md`](https://github.com/Pacha-e/OriginPass/blob/sprint-3-mvp/docs/GUIA-DEMO.md):
scan a genuine piece and read its journey, the revoked and not-found verdicts, the copy
alert in the analytics, an offer accepted and the journey growing, a revocation by the
administrator, and the audit log confirming the signed chain is intact.
